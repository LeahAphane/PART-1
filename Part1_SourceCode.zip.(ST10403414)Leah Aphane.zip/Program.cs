﻿using System;

namespace RecipeApplication
{
    class Recipe
    {
        // Private fields to store recipe details
        private string[] ingredients;
        private double[] quantities;
        private string[] units;
        private string[] steps;

        // Constructor to initialize empty recipe
        public Recipe()
        {
            // Initialize empty arrays for ingredients, quantities, units, and steps
            ingredients = new string[0];
            quantities = new double[0];
            units = new string[0];
            steps = new string[0];
        }

        // Method to enter recipe details
        public void EnterDetails()
        {
            // Prompt the user to enter the number of ingredients
            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Initialize the arrays with the correct size
            ingredients = new string[numIngredients];
            quantities = new double[numIngredients];
            units = new string[numIngredients];

            // Prompt the user to enter the details for each ingredient
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter details for ingredient #{i + 1}:");
                Console.Write("Name: ");
                ingredients[i] = Console.ReadLine();
                Console.Write("Quantity: ");
                quantities[i] = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                units[i] = Console.ReadLine();
            }

            // Prompt the user to enter the number of steps
            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            // Initialize the steps array with the correct size
            steps = new string[numSteps];

            // Prompt the user to enter the details for each step
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step #{i + 1}: ");
                steps[i] = Console.ReadLine();
            }
        }

        // Method to display the recipe
        public void DisplayRecipe()
        {
            // Display the ingredients and quantities
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < ingredients.Length; i++)
            {
                Console.WriteLine($"- {quantities[i]} {units[i]} of {ingredients[i]}");
            }

            // Display the steps
            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"- {steps[i]}");
            }
        }

        // Method to scale the recipe
        public void ScaleRecipe(double factor)
        {
            // Multiply all the quantities by the scaling factor
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] *= factor;
            }
        }

        // Method to reset quantities
        public void ResetQuantities()
        {
            // Reset all the quantities to their original values
            // (This method is not implemented yet)
            Console.WriteLine("Resetting quantities to original values...");
        }

        // Method to clear the recipe
        public void ClearRecipe()
        {
            // Reset all the arrays to empty
            ingredients = new string[0];
            quantities = new double[0];
            units = new string[0];
            steps = new string[0];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate a Recipe object
            Recipe recipe = new Recipe();

            // Main program loop
            while (true)
            {
                // Display menu options
                Console.WriteLine("\nEnter '1' to enter recipe details");
                Console.WriteLine("Enter '2' to display recipe");
                Console.WriteLine("Enter '3' to scale recipe");
                Console.WriteLine("Enter '4' to reset quantities");
                Console.WriteLine("Enter '5' to clear recipe");
                Console.WriteLine("Enter '6' to exit");

                // Read user choice
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        // Enter recipe details
                        recipe.EnterDetails();
                        break;
                    case "2":
                        // Display the recipe
                        recipe.DisplayRecipe();
                        break;
                    case "3":
                        // Scale the recipe
                        Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                        double factor = double.Parse(Console.ReadLine());
                        recipe.ScaleRecipe(factor);
                        break;
                    case "4":
                        // Reset quantities
                        recipe.ResetQuantities();
                        break;
                    case "5":
                        // Clear the recipe
                        recipe.ClearRecipe();
                        break;
                    case "6":
                        // Exit the program
                        Console.WriteLine("Exiting program...");
                        return;
                    default:
                        // Invalid choice
                        Console.WriteLine("Invalid choice. Please enter a valid choice.");
                        break;
                }
            }
        }
    }
}
